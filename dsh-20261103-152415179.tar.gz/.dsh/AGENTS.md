# 子智能体模型选择

- 每次调用 `subagent` 创建子智能体时，必须显式传入 `provider`、`model`、`reasoning_effort` 三个参数；不得省略参数来继承父会话的模型或思考等级。
- 选择模型前，用 `list_subagent_models` 查询对应路由及其支持的思考等级；根据任务复杂度选择受支持的 `reasoning_effort` 并显式填写。用户指定思考等级时优先遵从；若不受支持，先说明并确认替代方案。
